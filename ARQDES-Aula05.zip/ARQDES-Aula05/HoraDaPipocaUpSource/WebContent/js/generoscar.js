$( document ).ready(function() {

	$('.carouseller').each(function(i, obj) {
	    $(obj).carouseller({
	    	easing: 'linear'
	    })
	});
	
});